import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:luqma_app/core/error/failures.dart';
import 'package:luqma_app/core/network/api_constants.dart';
import 'package:luqma_app/core/network/dio_client.dart';
import 'package:luqma_app/core/storage/secure_storage_service.dart';
import 'package:luqma_app/features/cart/data/datasources/cart_remote_data_source.dart';
import 'package:luqma_app/features/cart/data/models/cart_mutation_request_model.dart';
import 'package:luqma_app/features/cart/domain/entities/cart_mutation.dart';

import '../support/cart_fixtures.dart';

void main() {
  test(
    'all Cart endpoints use protected Dio requests and exact routes',
    () async {
      final harness = _Harness();
      final request = CartMutationRequestModel.fromDomain(
        CartMutation(
          menuItemId: cartMenuItemId,
          quantity: 2,
          menuItemOptionId: cartOptionId,
          addonIds: const <String>[cartAddonId],
        ),
      );

      expect((await harness.source.addToCart(request)).id, cartLineId);
      harness.expectRequest(
        method: 'POST',
        path: ApiConstants.addToCart,
        body: <String, Object>{
          'menuItemId': cartMenuItemId,
          'quantity': 2,
          'menuItemOptionId': cartOptionId,
          'addonIds': const <String>[cartAddonId],
        },
      );
      expect((await harness.source.updateToCart(request)).isRemoved, isFalse);
      harness.expectRequest(
        method: 'PUT',
        path: ApiConstants.updateToCart,
        body: <String, Object>{
          'menuItemId': cartMenuItemId,
          'quantity': 2,
          'menuItemOptionId': cartOptionId,
          'addonIds': const <String>[cartAddonId],
        },
      );
      expect((await harness.source.getMyCart()).subTotal, 540);
      harness.expectRequest(method: 'GET', path: ApiConstants.getMyCart);
      expect((await harness.source.getCount()).totalQuantity, 2);
      harness.expectRequest(method: 'GET', path: ApiConstants.getCartCount);
      await harness.source.clearCart();
      harness.expectRequest(method: 'DELETE', path: ApiConstants.clearCart);
      expect(harness.storage.tokenReads, 5);
    },
  );

  test(
    'UpdateToCart sends the decrement exact menu item, option, and add-on IDs',
    () async {
      final harness = _Harness(
        body: cartEnvelope(data: <String, Object?>{'isRemoved': false}),
      );
      final decrement = CartMutationRequestModel.fromDomain(
        CartMutation(
          menuItemId: cartMenuItemId,
          quantity: 1,
          menuItemOptionId: cartOptionId,
          addonIds: const <String>[cartAddonId, otherCartAddonId],
        ),
      );

      final response = await harness.source.updateToCart(decrement);

      expect(response.isRemoved, isFalse);
      harness.expectRequest(
        method: 'PUT',
        path: ApiConstants.updateToCart,
        body: <String, Object?>{
          'menuItemId': cartMenuItemId,
          'quantity': 1,
          'menuItemOptionId': cartOptionId,
          'addonIds': const <String>[cartAddonId, otherCartAddonId],
        },
      );
    },
  );

  test(
    'UpdateToCart sends zero removal with the exact option and add-on identity',
    () async {
      final harness = _Harness(
        // This is the only response field confirmed for UpdateToCart. Do not
        // require a CartLine-shaped payload before the authoritative refresh.
        body: cartEnvelope(data: <String, Object?>{'isRemoved': true}),
      );
      final removal = CartMutationRequestModel.fromDomain(
        CartMutation(
          menuItemId: cartMenuItemId,
          quantity: 0,
          addonIds: const <String>[],
        ),
      );

      final response = await harness.source.updateToCart(removal);

      expect(response.isRemoved, isTrue);
      harness.expectRequest(
        method: 'PUT',
        path: ApiConstants.updateToCart,
        body: <String, Object?>{
          'menuItemId': cartMenuItemId,
          'quantity': 0,
          'menuItemOptionId': null,
          'addonIds': const <String>[],
        },
      );
    },
  );

  test(
    'unsuccessful envelope and network failures follow failure conventions',
    () async {
      final rejected = _Harness(
        body: cartEnvelope(data: null, succeeded: false, message: 'No cart'),
      );
      await expectLater(
        rejected.source.getMyCart(),
        throwsA(
          isA<RemoteException>().having(
            (error) => error.code,
            'code',
            FailureCode.validation,
          ),
        ),
      );

      final offline = _Harness(failure: DioExceptionType.connectionError);
      await expectLater(
        offline.source.getCount(),
        throwsA(
          isA<RemoteException>().having(
            (error) => error.code,
            'code',
            FailureCode.network,
          ),
        ),
      );
    },
  );
  test('structured 400 preserves only an explicit backend conflict code',
      () async {
    final request = CartMutationRequestModel.fromDomain(
      CartMutation(menuItemId: cartMenuItemId, quantity: 1),
    );
    final coded = _Harness(
        errorBody: {'message': 'rejected', 'errorCode': 'CART_STORE_CONFLICT'});
    await expectLater(
        coded.source.addToCart(request),
        throwsA(isA<RemoteException>()
            .having((e) => e.code, 'code', FailureCode.validation)
            .having(
                (e) => e.backendCode, 'backendCode', 'CART_STORE_CONFLICT')));
    final plain = _Harness(errorBody: {'message': 'invalid quantity'});
    await expectLater(
        plain.source.addToCart(request),
        throwsA(isA<RemoteException>()
            .having((e) => e.code, 'code', FailureCode.validation)
            .having((e) => e.backendCode, 'backendCode', isNull)));
  });
}

class _Harness {
  _Harness({Object? body, DioExceptionType? failure, Object? errorBody}) {
    final dio = Dio(BaseOptions(baseUrl: ApiConstants.baseUrl));
    addTearDown(() => dio.close(force: true));
    final client = DioClient(storage, dio: dio);
    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) {
          request = options;
          if (errorBody != null) {
            handler.reject(DioException(
                requestOptions: options,
                type: DioExceptionType.badResponse,
                response: Response<Object?>(
                    requestOptions: options,
                    statusCode: 400,
                    data: errorBody)));
            return;
          }
          if (failure != null) {
            handler.reject(
              DioException(requestOptions: options, type: failure),
            );
            return;
          }
          final data = body ?? _bodyFor(options.path);
          handler.resolve(
            Response<Object?>(
              requestOptions: options,
              statusCode: 200,
              data: data,
            ),
          );
        },
      ),
    );
    source = CartRemoteDataSourceImpl(client);
  }

  final _Storage storage = _Storage();
  late final CartRemoteDataSourceImpl source;
  RequestOptions? request;

  Object _bodyFor(String path) {
    if (path == ApiConstants.getMyCart) {
      return cartEnvelope(
        data: cartJson(
          items: <Object?>[cartLineJson()],
          totalQuantity: 2,
          subTotal: 540,
        ),
      );
    }
    if (path == ApiConstants.getCartCount) {
      return cartEnvelope(data: cartCountJson(linesCount: 1, totalQuantity: 2));
    }
    return cartEnvelope(data: cartLineJson());
  }

  void expectRequest({
    required String method,
    required String path,
    Object? body,
  }) {
    expect(request?.method, method);
    expect(request?.path, path);
    expect(request?.extra[DioClient.requiresAuthenticationExtraKey], isTrue);
    expect(request?.headers['Authorization'], 'Bearer test-token');
    expect(request?.data, body);
  }
}

class _Storage extends SecureStorageService {
  _Storage() : super(const FlutterSecureStorage());

  int tokenReads = 0;

  @override
  Future<String?> getToken() async {
    tokenReads++;
    return 'test-token';
  }
}
