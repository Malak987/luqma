import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:luqma_app/core/localization/app_localizations.dart';
import 'package:luqma_app/core/theme/app_colors.dart';
import 'package:luqma_app/core/theme/app_theme.dart';
import 'package:luqma_app/features/home/domain/entities/home_category.dart';
import 'package:luqma_app/features/home/presentation/cubit/home_state.dart';
import 'package:luqma_app/features/home/presentation/widgets/home_categories.dart';

import '../../support/main_category_fixtures.dart';

void main() {
  Future<void> pumpCategories(
    WidgetTester tester,
    HomeCategories categories, {
    Locale locale = const Locale('en'),
    ThemeData? theme,
    bool settle = true,
  }) async {
    await tester.pumpWidget(MaterialApp(
      theme: theme ?? AppTheme.light,
      localizationsDelegates: AppLocalizations.localizationsDelegates,
      supportedLocales: AppLocalizations.supportedLocales,
      locale: locale,
      home: Scaffold(body: SingleChildScrollView(child: categories)),
    ));
    if (settle) {
      await tester.pumpAndSettle();
    } else {
      await tester.pump();
    }
  }

  for (final locale in <Locale>[const Locale('ar'), const Locale('en')]) {
    testWidgets(
        'uses the inherited ${locale.languageCode} locale for category names',
        (tester) async {
      await pumpCategories(
        tester,
        HomeCategories(
          categories: [homeCategory(nameAr: 'مشويات', nameEn: 'Grills')],
        ),
        locale: locale,
      );

      expect(
        find.text(locale.languageCode == 'ar' ? 'مشويات' : 'Grills'),
        findsOneWidget,
      );
      expect(
        find.text(locale.languageCode == 'ar' ? 'Grills' : 'مشويات'),
        findsNothing,
      );
      expect(tester.takeException(), isNull);
    });

    testWidgets(
        'localizes the ${locale.languageCode} loading, error and empty states',
        (tester) async {
      final copy = AppLocalizations(locale).home;
      await pumpCategories(
        tester,
        const HomeCategories(
          categories: [],
          status: HomeCategoriesStatus.loading,
        ),
        locale: locale,
        settle: false,
      );
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
      expect(
        tester
            .widget<CircularProgressIndicator>(
              find.byType(CircularProgressIndicator),
            )
            .semanticsLabel,
        copy.categoriesLoading,
      );
      expect(find.text(copy.categoriesEmpty), findsNothing);

      var retries = 0;
      await pumpCategories(
        tester,
        HomeCategories(
          categories: const [],
          status: HomeCategoriesStatus.error,
          onRetry: () => retries++,
        ),
        locale: locale,
      );
      expect(find.text(copy.categoriesLoadFailed), findsOneWidget);
      expect(find.text(copy.categoriesEmpty), findsNothing);
      await tester.tap(find.byKey(const Key('home_categories_retry')));
      expect(retries, 1);

      await pumpCategories(
        tester,
        const HomeCategories(
          categories: [],
          status: HomeCategoriesStatus.empty,
        ),
        locale: locale,
      );
      expect(find.text(copy.categoriesEmpty), findsOneWidget);
      expect(
        find.byKey(const PageStorageKey('home_categories_rail')),
        findsNothing,
      );
      expect(find.byType(CircularProgressIndicator), findsNothing);
      expect(tester.takeException(), isNull);
    });
  }

  testWidgets(
      'initial state shows progress rather than a misleading empty state',
      (tester) async {
    await pumpCategories(
      tester,
      const HomeCategories(
        categories: [],
        status: HomeCategoriesStatus.initial,
      ),
      settle: false,
    );
    expect(find.byKey(const Key('home_categories_loading')), findsOneWidget);
    expect(find.byKey(const Key('home_categories_empty')), findsNothing);
  });

  testWidgets('uses the local icon fallback for unmatched category names',
      (tester) async {
    for (final iconUrl in <String?>[
      null,
      '',
      '   ',
      'not a URL',
      '/icons/category.png',
      'ftp://example.test/category.png',
      'javascript:alert(1)',
      'https:///category.png',
      'https://example.test/bad image.png',
      'https://[invalid',
    ]) {
      await pumpCategories(
        tester,
        HomeCategories(
          categories: [
            homeCategory(
              nameAr: 'فئة غير معروفة',
              nameEn: 'Unknown category',
              iconUrl: iconUrl,
            ),
          ],
        ),
      );
      expect(find.byType(Image), findsNothing, reason: 'Invalid URL: $iconUrl');
      expect(find.byIcon(Icons.restaurant_menu), findsOneWidget);
      expect(tester.takeException(), isNull);
    }
  });

  testWidgets(
      'maps supported Arabic and English category names to bundled assets',
      (tester) async {
    const categories = <HomeCategory>[
      HomeCategory(
        id: 'pharmacy',
        nameAr: 'صيدلية',
        nameEn: 'Pharmacy',
        iconUrl: null,
        displayOrder: 1,
        isActive: true,
      ),
      HomeCategory(
        id: 'drinks',
        nameAr: 'مشروبات',
        nameEn: 'Drinks',
        iconUrl: null,
        displayOrder: 2,
        isActive: true,
      ),
      HomeCategory(
        id: 'vegetables',
        nameAr: 'خضروات',
        nameEn: 'Vegetables',
        iconUrl: null,
        displayOrder: 3,
        isActive: true,
      ),
      HomeCategory(
        id: 'dessert',
        nameAr: 'حلويات',
        nameEn: 'Dessert',
        iconUrl: null,
        displayOrder: 4,
        isActive: true,
      ),
      HomeCategory(
        id: 'food',
        nameAr: 'مأكولات',
        nameEn: 'Food',
        iconUrl: null,
        displayOrder: 5,
        isActive: true,
      ),
    ];

    await pumpCategories(
      tester,
      const HomeCategories(categories: categories),
    );

    // Each category resolves to its own transparent-background illustration.
    expect(find.byType(SvgPicture), findsNWidgets(5));
    for (final asset in <String>[
      'assets/category_icons/pharmacy.svg',
      'assets/category_icons/drinks.svg',
      'assets/category_icons/vegetables.svg',
      'assets/category_icons/dessert.svg',
      'assets/category_icons/food.svg',
    ]) {
      expect(find.byKey(ValueKey<String>(asset)), findsOneWidget,
          reason: 'missing artwork for $asset');
    }
    expect(find.byType(Image), findsNothing);
    expect(find.byIcon(Icons.restaurant_menu), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('prefers the API category image when a valid URL is supplied',
      (tester) async {
    await pumpCategories(
      tester,
      HomeCategories(
        categories: [
          homeCategory(
            nameAr: 'مطاعم',
            nameEn: 'Restaurants',
            iconUrl: 'https://luqma-api.runasp.net/icons/categories/restaurants.png',
          ),
        ],
      ),
    );

    final image = tester.widget<Image>(find.byType(Image).first);
    expect(image.image, isA<NetworkImage>());
    expect(image.fit, BoxFit.contain);
    expect(image.excludeFromSemantics, isTrue);
    expect(tester.takeException(), isNull);
  });

  testWidgets('category items are card-less with a circular icon backdrop',
      (tester) async {
    for (final theme in <ThemeData>[AppTheme.light, AppTheme.dark]) {
      await pumpCategories(
        tester,
        // Default fixture id, so the key lookup below uses the same id.
        HomeCategories(categories: [homeCategory()]),
        theme: theme,
      );

      // No box, border or shadow around a category: the illustration floats.
      expect(find.byType(Card), findsNothing);

      final colors = theme.extension<AppSemanticColors>()!;
      final iconTile = tester.widget<Container>(
        find.byKey(const Key('category_icon_background_$mainCategoryId')),
      );
      final decoration = iconTile.decoration! as BoxDecoration;
      expect(decoration.color, colors.iconSurface);
      expect(decoration.shape, BoxShape.circle);
      expect(decoration.gradient, isNull);
      expect(decoration.boxShadow, isNull);

      // Dark mode tints the fixed-palette line art so it keeps its contrast.
      expect(find.byType(ColorFiltered),
          theme.brightness == Brightness.dark ? findsOneWidget : findsNothing);
      expect(tester.takeException(), isNull);
    }
  });

  testWidgets('keeps the category rail horizontally scrollable at 320px',
      (tester) async {
    await tester.binding.setSurfaceSize(const Size(320, 800));
    addTearDown(() => tester.binding.setSurfaceSize(null));

    await pumpCategories(
      tester,
      HomeCategories(
        categories: List<HomeCategory>.generate(
          6,
          (index) => homeCategory(
            id: 'cat-$index',
            nameAr: 'قسم $index',
            nameEn: 'Category $index',
          ),
        ),
      ),
    );

    final rail = tester.widget<ListView>(
      find.byKey(const PageStorageKey('home_categories_rail')),
    );
    expect(rail.scrollDirection, Axis.horizontal);
    expect(find.byKey(const Key('category_card_cat-0')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
